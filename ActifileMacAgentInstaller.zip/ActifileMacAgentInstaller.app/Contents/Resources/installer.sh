#!/bin/sh

#  installer.sh
#  Actifile
#
#  Created by Oleg Kulchytskyi on 9/10/19.
#  Copyright © 2019 Actifile. All rights reserved.

function usage
{
    echo "Usage:"
    echo "    $1 install <SRC_PATH> <DST_PATH> <INST_KEY> <INST_USER> <DEV_UUID> <UNINST_KEY>"
    echo "    $1 uninstall <DST_PATH> <INST_USER>"
    exit 1
}

function log_step
{
    echo -e "========================================"
    echo -e "$1"
    echo -e "========================================\n"
}

function copy_artifact
{
    echo -e "Copy Artifact \n$SRC_PATH/$1 \n$DST_PATH/$1 \n"
    cp -r "$SRC_PATH/$1" "$DST_PATH/$1"
    chmod -R $2 "$DST_PATH/$1"
    chown -R root:wheel "$DST_PATH/$1"
}

#
# USAGE: install_daemon <PLIST_PATH> <EXEC_PATH> <IN_BUNDLE>
#
function install_daemon
{
    if [ $# -lt 2 ]
    then
        echo "$FUNCNAME -- not enough input parameters"
        return 1
    fi

    local DAEMON_PATH="/Library/LaunchDaemons/$1"
    local DAEMON_EXEC="$DST_PATH/$2$3"
    local DAEMON_LOG="$DST_PATH/${1%.*}.log"

    log_step "Installing Daemon $DAEMON_PATH"

    if [ -f "$DAEMON_PATH" ]
    then
        launchctl bootout system "$DAEMON_PATH" &>/dev/null
    fi

    copy_artifact "$2" 755

    #
    # NOTE: Copy daemon plist
    #
    cp -r "$SRC_PATH/$1" "$DAEMON_PATH"
    chmod -R 644 "$DAEMON_PATH"
    chown -R root:wheel "$DAEMON_PATH"

    echo "$DAEMON_EXEC"
    plutil -replace "ProgramArguments" -json "[\"$DAEMON_EXEC\"]" "$DAEMON_PATH"
    plutil -replace "StandardOutPath" -string "$DAEMON_LOG" "$DAEMON_PATH"
    plutil -replace "StandardErrorPath" -string "$DAEMON_LOG" "$DAEMON_PATH"

    log_step "Launching Daemon $DAEMON_PATH"

    launchctl bootstrap system "$DAEMON_PATH"
    if [ $? -ne 0 ]
    then
        echo "Failed to launch Daemon $DAEMON_PATH"
        return 1
    fi
}

#
# USAGE: uninstall_daemon <PLIST_PATH>
#
function uninstall_daemon
{
    if [ $# -ne 1 ]
    then
        echo "$FUNCNAME -- not enough input parameters"
        return 1
    fi

    local DAEMON_PATH="/Library/LaunchDaemons/$1"
    local DAEMON_NAME="${1%.*}"

    launchctl bootout system "$DAEMON_PATH" &> /dev/null
    local BOOTOUT_STATUS=$?
    # status 36 -- EINPROGRESS
    if [[ $BOOTOUT_STATUS != 0 && $BOOTOUT_STATUS != 36 ]]
    then
        echo "Failed to stop Daemon $DAEMON_PATH -- $BOOTOUT_STATUS"
        return 1
    fi

    if [[ $BOOTOUT_STATUS == 36 ]]
    then
        while [[ `launchctl list $DAEMON_NAME &> /dev/null` == 0 ]]
        do
            sleep 1
        done
    fi

    rm "$DAEMON_PATH"
}

#
# USAGE: install_agent <PLIST_PATH> <EXEC_PATH> <IN_BUNDLE>
#
function install_agent
{
    if [ $# -ne 2 ]
    then
        echo "$FUNCNAME -- not enough input parameters"
        return 1
    fi

    local AGENT_PATH="$LAUNCH_AGENTS_PATH/$1"
    local AGENT_EXEC="$USER_DST_PATH/$2$3"
    local AGENT_LOG="$USER_DST_PATH/${1%.*}.log"

    log_step "Installing Agent $AGENT_PATH"

    if [ -f "$AGENT_PATH" ]
    then
        launchctl bootout gui/$INST_UID $AGENT_PATH
    fi

    cp -r "$SRC_PATH/$1" "$AGENT_PATH"
    chmod -R 644 "$AGENT_PATH"
    chown -R $INST_USER:staff "$AGENT_PATH"

    cp -r "$SRC_PATH/$2" "$AGENT_EXEC"
    chmod -R 755 "$AGENT_EXEC"
    chown -R $INST_USER:staff "$AGENT_EXEC"

    plutil -replace "ProgramArguments" -json "[\"$AGENT_EXEC\"]" "$AGENT_PATH"
    plutil -replace "StandardOutPath" -string "$AGENT_LOG" "$AGENT_PATH"
    plutil -replace "StandardErrorPath" -string "$AGENT_LOG" "$AGENT_PATH"

    log_step "Launching Agent $AGENT_PATH"

    launchctl bootstrap gui/$INST_UID "$AGENT_PATH"
    if [ $? -ne 0 ]
    then
        echo "Failed to launch Agent $AGENT_PATH"
        exit 1
    fi
}

#
# USAGE: uninstall_agent <PLIST_PATH>
#
function uninstall_agent
{
    if [ $# -ne 1 ]
    then
        echo "$FUNCNAME -- not enough input parameters"
        return 1
    fi

    local AGENT_PATH="$LAUNCH_AGENTS_PATH/$1"
    local AGENT_NAME="${1%.*}"

    launchctl bootout gui/$INST_UID "$AGENT_PATH" &> /dev/null
    local BOOTOUT_STATUS=$?
    # status 36 -- EINPROGRESS
    if [[ $BOOTOUT_STATUS != 0 && $BOOTOUT_STATUS != 36 ]]
    then
        echo "Failed to stop Agent $AGENT_PATH -- $BOOTOUT_STATUS"
    fi

    if [[ $BOOTOUT_STATUS == 36 ]]
    then
        while [[ `sudo -u $INST_USER launchctl list $AGENT_NAME &> /dev/null` == 0 ]]
        do
            sleep 1
        done
    fi

    rm "$AGENT_PATH"
}

#
# USAGE: install_actifile <SRC_PATH> <DST_PATH> <INST_KEY> <INST_USER> <DEV_UUID> <UNINST_KEY>
#
function install_actifile
{
    if [ $# != 6 ]
    then
        echo "$FUNCNAME -- not enough input parameters"
        usage $0
    fi

    if [ ! -d "$1" ]
    then
        echo "Source path $1 -- Does not exists"
        usage $0
    fi

    local SRC_PATH="${1%%/}"
    local DST_PATH="${2%%/}"
    local INST_KEY=$3
    local INST_USER=$4
    local INST_UID=`id -u $INST_USER`
    local DEV_UUID=$5
    local UNINST_KEY=$6
    local LAUNCH_AGENTS_PATH="/Users/$INST_USER/Library/LaunchAgents"
    local USER_DST_PATH="/Users/$INST_USER/$DST_PATH"

    log_step "Creating $DST_PATH"

    mkdir -p "$DST_PATH"
    if [ $? -ne 0 ]
    then
        echo "Failed to create DST_PATH -- $DST_PATH"
        return 1
    fi

    log_step "Creating $LAUNCH_AGENTS_PATH"

    mkdir -p "$LAUNCH_AGENTS_PATH"
    if [ $? -ne 0 ]
    then
        echo "Failed to create LAUNCH_AGENTS_PATH -- $LAUNCH_AGENTS_PATH"
        return 1
    fi
    chown $INST_USER:staff $LAUNCH_AGENTS_PATH

    log_step "Creating $USER_DST_PATH"

    mkdir -p "$USER_DST_PATH"
    if [ $? -ne 0 ]
    then
        echo "Failed to create USER_DST_PATH -- $USER_DST_PATH"
        return 1
    fi
    chown $INST_USER:staff "$USER_DST_PATH"

    #
    # NOTE: Copy and prepare settings
    #
    copy_artifact "settings.json" 644

    OUTPUT=`sed 's/${DEV_UUID}/'$DEV_UUID'/g' "$DST_PATH/settings.json"`
    echo "$OUTPUT" > "$DST_PATH/settings.json"
    OUTPUT=`sed 's/${INST_KEY}/'$INST_KEY'/g' "$DST_PATH/settings.json"`
    echo "$OUTPUT" > "$DST_PATH/settings.json"
    OUTPUT=`sed 's/${INST_USER}/'$INST_USER'/g' "$DST_PATH/settings.json"`
    echo "$OUTPUT" > "$DST_PATH/settings.json"
    OUTPUT=`sed 's/${UNINST_KEY}/'$UNINST_KEY'/g' "$DST_PATH/settings.json"`
    echo "$OUTPUT" > "$DST_PATH/settings.json"

    #
    # NOTE: Generate Updater ID. Make positive int in range 0...1000000
    #
    UPDATER_ID=$((`od -An -N4 -i /dev/urandom | sed 's/-//g'` % 1000000))
    OUTPUT=`sed 's/${UPDATER_ID}/'$UPDATER_ID'/g' "$DST_PATH/settings.json"`
    echo "$OUTPUT" > "$DST_PATH/settings.json"

    install_daemon "com.actifile.afmond.plist" "afmond.app" "/Contents/MacOS/afmond"
    install_daemon "com.actifile.updaterd.plist" "updaterd"
    install_agent "com.actifile.UserAgent.plist" "UserAgent"

    #
    # NOTE: copy installer script for remote uninstallation support
    #
    SCRIPT_NAME="${0##*/}"
    copy_artifact "$SCRIPT_NAME" 755
}

#
# USAGE: uninstall_actifile <DST_PATH> <INST_USER>
#
function uninstall_actifile
{
    if [ $# != 2 ]
    then
        echo "$FUNCNAME -- not enough input parameters"
        usage $0
    fi

    if [ ! -d "$1" ]
    then
        echo "Destination path $1 -- Does not exists"
        usage $0
    fi

    local DST_PATH="${1%%/}"
    local INST_USER=$2
    local INST_UID=`id -u $INST_USER`
    local LAUNCH_AGENTS_PATH="/Users/$INST_USER/Library/LaunchAgents"
    local USER_DST_PATH="/Users/$INST_USER/$DST_PATH"

    log_step "Uninstalling afmond"
    uninstall_daemon "com.actifile.afmond.plist"

    log_step "Uninstalling updaterd"
    uninstall_daemon "com.actifile.updaterd.plist"

    log_step "Uninstalling UserAgent"
    uninstall_agent "com.actifile.UserAgent.plist"

    log_step "Removing files"
    rm -rf "$DST_PATH"
    rm -f "$USER_DST_PATH/UserAgent"
    rm -f "$USER_DST_PATH/com.actifile.UserAgent.log"
    rm -f "$USER_DST_PATH/Cache.db"
    rm -rf "$USER_DST_PATH/Requests"
    rm -f "$USER_DST_PATH/*.csv"
    rm -f "$USER_DST_PATH/state.json"
}

case $1 in
"install")
    if [ $# != 7 ]
    then
        echo "$0 -- not enough input parameters"
        usage $0
    fi

    install_actifile "$2" "$3" "$4" "$5" "$6" "$7"

    if [ $? -ne 0 ]
    then
        uninstall_actifile "$3" "$5"
        usage $0
    fi

    ;;

"uninstall")
    if [ $# != 3 ]
    then
        echo "$0 -- not enough input parameters"
        usage $0
    fi

    uninstall_actifile "$2" "$3"

    ;;

#
# WARN: This subcommand only for internal usage
#
"selfuninstall")
    if [ $# != 4 ]
    then
        echo "$0 -- not enough input parameters"
        exit 1
    fi

    if [ ! -f "$4" ]
    then
        echo "$4 -- file does not exists"
        exit 1
    fi

    uninstall_actifile "$2" "$3"
    log_step "Running selfuninstall stop -- $4"
    launchctl bootout system "$4"

    ;;

*)
    usage $0
    ;;
esac
